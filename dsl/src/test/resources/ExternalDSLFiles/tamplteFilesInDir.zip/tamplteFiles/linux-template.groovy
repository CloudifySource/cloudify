[
	SMALL_LINUX : template 	{
				
								imageId "OpenLogic__OpenLogic-CentOS-62-20120531-en-us-30GB.vhd"
								machineMemoryMB 1600
								hardwareId "Small"
								localDirectory "upload"
					
								username "SMALL_LINUX"
								password "ENTER_PASSWORD"
					
								remoteDirectory "/home/ENTER_USER_NAME/gs-files"
							}
]